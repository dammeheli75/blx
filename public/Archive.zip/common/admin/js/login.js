$(document).ready(function () {
    $('#error-modal').modal('show');
});
$(document).ready(function () {
    $('#blx-social-network-fixed-left-side').css('left', ($(window).width() - 960) / 2 - 50);
});
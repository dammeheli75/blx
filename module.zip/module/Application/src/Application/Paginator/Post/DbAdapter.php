<?php
namespace Application\Paginator\Post;

use Zend\Paginator\Adapter\DbSelect;

class DbAdapter extends DbSelect
{
    
}
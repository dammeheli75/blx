Sample, skeleton module for use with the ZF2 MVC layer.
